/**
 * SERVICES COMPONENTS INDEX
 */

export * from './ServiceCard';
