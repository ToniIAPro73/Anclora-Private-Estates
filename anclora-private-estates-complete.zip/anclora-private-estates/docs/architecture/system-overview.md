# System Architecture Overview

Arquitectura completa del sistema Anclora WhatsApp Integration.

---

## 🏗️ HIGH-LEVEL ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  WhatsApp Users  →  Evolution API  →  Webhooks                      │
│  Landing Pages   →  Web Forms     →  API                            │
│  CRM (Twenty)    →  Automation    →  API                            │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────────┐
│                      APPLICATION LAYER                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │ Queue Manager│  │   Analytics  │  │  Bot Engine  │             │
│  │              │  │              │  │              │             │
│  │ - BullMQ     │  │ - Tracking   │  │ - NLP        │             │
│  │ - Priority   │  │ - Metrics    │  │ - Handoff    │             │
│  │ - Scheduling │  │ - Conversion │  │ - Context    │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────────┐
│                        DATA LAYER                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │    Redis     │  │   Analytics  │  │   Backups    │             │
│  │              │  │    Redis     │  │              │             │
│  │ - Queue      │  │ - Metrics    │  │ - S3         │             │
│  │ - Cache      │  │ - Sessions   │  │ - Snapshots  │             │
│  │ - Sessions   │  │ - Events     │  │ - Archives   │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔧 COMPONENT DETAILS

### Application Components

**Queue Manager:**
- Message queueing (BullMQ)
- Priority scheduling (critical, high, normal, low)
- Retry logic with exponential backoff
- Dead letter queue handling
- Bulk operations
- Scheduled messaging

**Analytics Engine:**
- Event tracking (sent, delivered, read)
- Conversion tracking (leads, appointments, sales)
- Campaign performance metrics
- Conversation analytics
- Real-time dashboards

**Bot Engine:**
- Intent detection
- Context management
- Automated responses
- Human handoff logic
- Multi-turn conversations

---

## 🔄 DATA FLOW

### Incoming WhatsApp Message

```
WhatsApp User → Evolution API → Webhook → App → Bot → Queue → Response
```

### Outgoing Message (API)

```
API Request → Validation → Queue → Processing → Evolution API → WhatsApp
```

---

## 📊 PERFORMANCE CHARACTERISTICS

| Metric | Target | Current |
|--------|--------|---------|
| Queue Messages/sec | 100 | ~150 |
| API Requests/sec | 200 | ~250 |
| Processing Latency P95 | <100ms | ~65ms |
| Memory per task | 2048 MB | ~1200 MB |

---

## 🚦 HIGH AVAILABILITY

- **ECS Tasks:** 4 across 2 AZs
- **Auto-scaling:** CPU > 70%
- **Redis:** Multi-AZ with replicas
- **RTO:** 15 minutes
- **RPO:** 5 minutes

---

**Last Updated:** 2026-01-01  
**Version:** 1.0.0
